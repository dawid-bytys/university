# Zadanie 5

<div style="text-align: right">Dawid Bytys Kraków 24.04.2022</div>
<br />
<br />

### O programie

Zadanie 5 polega utworzeniu strumienia nazwanego, do którego pobieramy dane z pliku, a następnie zczytujemy z niego odpowiednią porcję bajtów i zapisujemy w drugim pliku.

1. Kompilacja

```bash
$ make all
```

2. Uruchomienie

```bash
$ make run
```
