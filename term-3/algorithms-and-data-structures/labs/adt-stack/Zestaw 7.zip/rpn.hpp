#include <string>
#include <vector>

int rpn(std::vector<std::string> input);