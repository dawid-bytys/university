package pl.edu.uj.kolos;

class Treasure extends Position {
    Treasure(final double x, final double y) {
        super(x, y);
    }
}
