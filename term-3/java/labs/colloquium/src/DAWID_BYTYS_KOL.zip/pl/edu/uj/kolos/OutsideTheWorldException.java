package pl.edu.uj.kolos;

class OutsideTheWorldException extends Exception {
    public OutsideTheWorldException(final String message) {
        super(message);
    }
}