package pl.edu.uj.kolos;

public class BoundaryException extends Exception {
    public BoundaryException(final String message) {
        super(message);
    }
}
