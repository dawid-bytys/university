#include "tests.cpp"

int main() {
  run_all_tests();
  return 0;
}